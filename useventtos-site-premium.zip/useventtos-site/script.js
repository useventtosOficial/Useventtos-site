const header = document.querySelector('.header');

window.addEventListener('scroll', () => {
  const value = Math.min(window.scrollY / 500, 1);
  header.style.boxShadow = `0 10px 30px rgba(0,0,0,${value * 0.08})`;
});

const product = document.querySelector('.sneaker-card');
window.addEventListener('mousemove', (e) => {
  const x = (e.clientX / window.innerWidth - 0.5) * 8;
  const y = (e.clientY / window.innerHeight - 0.5) * 8;
  product.style.transform = `rotate(${-4 + x}deg) translateY(${y}px)`;
});

# Useventtos Site

Landing page estática da Useventtos.

## Como publicar grátis

Opção simples:
1. Crie uma conta no Netlify.
2. Arraste a pasta `useventtos-site` para o painel do Netlify.
3. O site será publicado automaticamente.

Opção GitHub Pages:
1. Crie um repositório chamado `useventtos-site`.
2. Envie os arquivos `index.html`, `style.css` e `script.js`.
3. Ative GitHub Pages nas configurações do repositório.

Depois é possível conectar um domínio como `useventtos.com.br`.
